package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Student;
import util.DBUtil;

public class StudentDAO {
	 public void addStudent(Student s) throws SQLException {
	        String sql = "INSERT INTO students (name, age) VALUES (?, ?)";
	        Connection conn = DBUtil.getConnection();
	          System.out.println("conneciton"+conn);
	             PreparedStatement ps = conn.prepareStatement(sql);
	            ps.setString(1, s.getName());
	            ps.setInt(2, s.getAge());
	            ps.executeUpdate();
	            System.out.println("Record inserted successfully");
	        
	    }
	 public List<Student> getAllStudents() throws SQLException {
	        List<Student> list = new ArrayList<>();
	        String sql = "SELECT id, name, age FROM students ORDER BY id";
	        try (Connection conn = DBUtil.getConnection();
	             PreparedStatement ps = conn.prepareStatement(sql);
	             ResultSet rs = ps.executeQuery()) {
	            while (rs.next()) {
	                list.add(new Student(rs.getInt("id"), rs.getString("name"), rs.getInt("age")));
	            }
	        }
	        return list;
	    }

}
