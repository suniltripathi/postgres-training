package test;

import java.sql.Connection;
import java.sql.SQLException;

import util.DBUtil;

public class Test {

	public static void main(String[] args) {
		
	    System.out.println("Hello");
		Connection con = DBUtil.getConnection();
		System.out.println(con);
	    

	}

}
