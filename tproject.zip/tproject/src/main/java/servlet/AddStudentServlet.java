package servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.StudentDAO;
import model.Student;

public class AddStudentServlet extends HttpServlet{
	private final StudentDAO dao = new StudentDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("UTF-8");
        String name = req.getParameter("name");
        String ageStr = req.getParameter("age");
        String error = null;

        if (name == null || name.trim().isEmpty()) {
            error = "Name is required.";
        }

        int age = 0;
        try {
            age = Integer.parseInt(ageStr);
            if (age <= 0) error = "Age must be a positive integer.";
        } catch (NumberFormatException e) {
            error = "Age must be a valid integer.";
        }

        if (error != null) {
            // preserve values and show error on form
            req.setAttribute("error", error);
            req.setAttribute("name", name);
            req.setAttribute("age", ageStr);
            req.getRequestDispatcher("addStudent.jsp").forward(req, resp);
            return;
        }

        try {
            dao.addStudent(new Student(name.trim(), age));
            // redirect to list page after successful insert (PRG pattern)
            resp.setContentType("text/html"); // Tell browser to expect HTML
            PrintWriter out = resp.getWriter();
            out.println("<html><body>");
            out.println("<h2 style='color:green;'>Record inserted successfully!</h2>");
            //out.println("<a href='listStudents'>View Students</a>");
            out.println("<a href='" + req.getContextPath() + "/listStudents'>View Students</a>");
            out.println("</body></html>");
           // resp.sendRedirect(req.getContextPath() + "/listStudents");
                    
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Database error: " + e.getMessage());
            req.getRequestDispatcher("addStudent.jsp").forward(req, resp);
        }
    }

    // If user opens /addStudent via GET, show the form
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.getRequestDispatcher("addStudent.jsp").forward(req, resp);
    }

}
